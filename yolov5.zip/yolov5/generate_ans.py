import os
import sys

filenames=os.listdir(sys.argv[1])
filenames.sort(key=lambda x:int(x[7:-4]))
result = {}
for name in filenames:
    #result[name] = []
    #with open(os.path.join( sys.argv[1], name),'r') as f:
    f = open(os.path.join( sys.argv[1], name))
    k = f.readlines()
    name = name[:-4]+".jpg"
    result[name] = []

    for a in k:
        a = a.split('\n')[0]
        tmp = a.split(' ')[1:]
        for i in range(len(tmp)):
            tmp[i] = float(tmp[i])
        conf = round(float(tmp[4]),5)

        width =1716
        height = 942
        center_x = int(tmp[0]*width)
        center_y = int(tmp[1]*height)
        w = int(tmp[2]*width)
        h = int(tmp[3]*height)

        x = int(center_x - w/2)
        y = int(center_y - h/2)
        xmin = x if x>0 else 0
        ymin = y if y>0 else 0
        xmax = x+w if x+w <width else width
        ymax = y+h if y+h <height  else height
        data = [xmin,ymin,xmax,ymax,conf]
        #print(tmp)
        result[name].append(data)
    f.close()

import json
File = open(sys.argv[2], "w")
json.dump(result, File)
File.close()

python3 generate_ans.py  ./runs/detect/exp13/labels/ ./fuck-5l6-1280.json

import os
splits = ["train", "dev"]
for split in splits:
    filenames = os.listdir(split)
    # print(len(filenames))
    for fname in filenames:
        file = open(os.path.join(split, fname), "r")
        replacement = ""
        # using the for loop
        for line in file:
            line = line.strip()
            changes = '0' + line[1:]
            # print(change)
            replacement = replacement + changes + "\n"
        file.close()
        # opening the file in write mode
        fout = open(os.path.join(split, fname), "w")
        fout.write(replacement)
        fout.close()

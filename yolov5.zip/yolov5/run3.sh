# python3 train.py --local_rank=0 --img 1280 --batch 4 --data ./custom.yaml --weights yolov5m.pt --hyp ./data/hyps/hyp.scratch-high.yaml  --device 4 --epochs 150 --name 5m1280_model_
# python3 train.py --local_rank=0 --img 1280 --batch 4 --data ./custom.yaml --weights yolov5m6.pt --hyp ./data/hyps/hyp.scratch-high.yaml  --device 4 --epochs 150 --name 5m61280_model_
# python3 train.py --local_rank=0 --img 1280 --batch 2 --data ./custom.yaml --weights yolov5l.pt --hyp ./data/hyps/hyp.scratch-high.yaml  --device 4 --epochs 150 --name 5l1280_model_
# python3 train.py --local_rank=0 --img 1280 --batch 2 --data ./custom.yaml --weights yolov5l6.pt --hyp ./data/hyps/hyp.scratch-high.yaml  --device 4 --epochs 150 --name 5l61280_model_
# python3 train.py --img 1280 --batch 2 --data ./custom.yaml --weights yolov5l.pt --hyp ./data/hyps/hyp.scratch-high.yaml  --device 0 --epochs 150 --name new_5l1280
# python3 train.py --img 1280 --batch 4 --data ./custom.yaml --weights yolov5l6.pt --hyp ./data/hyps/hyp.scratch-high.yaml  --device 4 --epochs 150 --name new_5l61280
python3 train.py --img 1280 --batch 2 --data ./custom.yaml --weights yolov5x.pt --hyp ./data/hyps/hyp.scratch-high.yaml  --device 0 --epochs 300 --name damn_latest_5x

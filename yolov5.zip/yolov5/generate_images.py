import cv2
import numpy as np
import os

#net = cv2.dnn.readNet('yolov3_training_last.weights', 'yolov3_testing.cfg')

#classes = []
#with open("classes.txt", "r") as f:
    #classes = f.read().splitlines()

#cap = cv2.VideoCapture('video4.mp4')
#cap = 'test_images/<your_test_image>.jpg'

import json
with open('./i.json') as f:
    data = json.load(f)

font = cv2.FONT_HERSHEY_PLAIN
#colors = np.random.uniform(0, 255, size=(100, 3))
color = (0,0,0)
filenames=os.listdir('./Public_Image')
filenames.sort(key=lambda x:int(x[7:-4]))
result = {}
count =0
for picture_name in filenames:
    print(picture_name)
    result[picture_name] = []
    img = cv2.imread("Public_Image/"+picture_name)
    print(len(data[picture_name]))
    if len(data[picture_name])>0:
        for item in data[picture_name]:
            xmin = item[0]
            ymin = item[1]
            xmax = item[2]
            ymax = item[3]
            confidence = item[4]
            cv2.rectangle(img, (xmin ,ymin), (xmax, ymax), color, 2)
            cv2.putText(img, "stat  " + str(confidence), (xmin, ymin+20), font, 1, (0,0,0), 2)

    cv2.imwrite('./v5_result/'+picture_name, img)

#print("bounding box number : ",count)
cv2.destroyAllWindows()

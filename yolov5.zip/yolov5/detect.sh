python3 detect.py --weights ./runs/train/5l61280_model_/weights/best.pt  --data ./custom.yaml --source ./test_images --device 4

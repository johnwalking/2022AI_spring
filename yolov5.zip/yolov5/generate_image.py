import cv2
import numpy as np
import os
import json

with open('./fuck-wala-5l.json') as f:
    data = json.load(f)

font = cv2.FONT_HERSHEY_PLAIN
color = (0,0,0)
filenames=os.listdir('./data/Public_Image')
filenames.sort(key=lambda x:int(x[7:-4]))
result = {}
count =0
for picture_name in filenames:
    print(picture_name)
    result[picture_name] = []
    img = cv2.imread("./data/Public_Image/"+picture_name)
    print(len(data[picture_name]))
    if len(data[picture_name])>0:
        for item in data[picture_name]:
            xmin = item[0]
            ymin = item[1]
            xmax = item[2]
            ymax = item[3]
            confidence = item[4]
            cv2.rectangle(img, (xmin ,ymin), (xmax, ymax), color, 2)
            cv2.putText(img, "stat  " + str(confidence), (xmin, ymin+20), font, 1, (0,0,0), 2)

    cv2.imwrite('./5l_predictions/'+picture_name, img)

#print("bounding box number : ",count)
cv2.destroyAllWindows()
